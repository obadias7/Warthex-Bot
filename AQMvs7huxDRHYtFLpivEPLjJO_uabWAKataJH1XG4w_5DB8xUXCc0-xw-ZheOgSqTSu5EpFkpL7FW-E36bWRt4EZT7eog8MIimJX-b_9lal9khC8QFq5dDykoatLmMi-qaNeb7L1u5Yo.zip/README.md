# WarthexBot_24h - Bedrock 24/7

Bot configurado para:
IP: 168.119.78.155 (obsidianorb.falix.pro)
Porta: 20036
Username: WarthexBot_24h
Versão: auto (suporta +1.21.0)
Offline: true (cracked)

## Como usar no Render.com
1. Crie um novo Web Service
2. Faça upload deste .zip ou conecte no GitHub
3. Build Command: npm install
4. Start Command: npm start
5. Environment: Node 18+
6. Plano Free já funciona 24/7 (com sleeps, mas bot reconecta)

## Como usar no Replit
1. Importe o .zip
2. Clique em Run
3. Deixe sempre rodando (Use UptimeRobot pingando a URL do Repl para 24/7)

O bot tem:
- Reconexão automática infinita com backoff
- Version auto
- KeepAlive
- Servidor HTTP para não cair no Render
